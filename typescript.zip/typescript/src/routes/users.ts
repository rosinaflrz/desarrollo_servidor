import { Router } from 'express';
import usersController from '../controllers/users.controllers';
import { authMiddleware } from '../middlewares/auth';
const router = Router();

router.get('', authMiddleware, usersController.getAll);

export default router;