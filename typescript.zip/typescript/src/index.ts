import express, { Request, Response} from 'express';
import routes from './routes';
import './types/custom';


const app = express();

const port = process.env.PORT || 3000;

//ctrl+esp
app.get('', (req: Request, res: Response) => {
    res.send('Api works');
})

app.use(routes);

app.listen(port, () => {
    console.log(`app is running in port ${port}`);
})