import { Request, Response } from "express";

export class UsersController {
    getAll(req: Request, res: Response) { //si ya cree la instancia const... no necesita ser estatico
        res.send([]);
    }
}

const usersController = new UsersController();
export default usersController;