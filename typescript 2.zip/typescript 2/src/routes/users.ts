import { Router } from 'express';
import usersController from '../controllers/users.controllers';
import { authMiddleware, roles } from '../middlewares/auth';

const router = Router();

router.get('/users', authMiddleware, roles(['admin', 'gerente']), usersController.getAll);

export default router;
