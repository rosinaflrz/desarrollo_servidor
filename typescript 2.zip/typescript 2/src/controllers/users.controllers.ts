import { Request, Response } from "express";

export class UsersController {
    getAll(req: Request, res: Response) {
        console.log('Entrando al controlador de usuarios');  // Verificación de la entrada
        const users = [
            { id: 1, name: 'Rosina Flores', role: 'admin' },
            { id: 2, name: 'John Doe', role: 'gerente' }
        ];
        res.json({ message: 'Usuarios encontrados', users });  // Enviar usuarios con un mensaje
    }
}

const usersController = new UsersController();
export default usersController;
