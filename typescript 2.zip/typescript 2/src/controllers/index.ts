export * from "./users.controllers";
export * from "./peluches.controllers";
import usersController from "./users.controllers";
import peluchesController from "./peluches.controllers";

export default {
    usersController,
    peluchesController
}
