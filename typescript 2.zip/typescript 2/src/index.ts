import express, { Request, Response } from 'express';
import routes from './routes'; // Asegúrate de que este archivo contiene las rutas

const app = express();

const port = process.env.PORT || 3000;

app.get('', (req: Request, res: Response) => {
    res.send('Api works');
});

// Usa las rutas definidas en el archivo 'routes/index.ts'
app.use(routes);

app.listen(port, () => {
    console.log(`app is running in port ${port}`);
});
