import { Request, Response, NextFunction } from 'express';
import { User } from '../types/user';

const secretKey = '12345';

export function authMiddleware(req: Request, res: Response, next: NextFunction) {
    const key = req.query.key;
    if (key === secretKey) {
        // Usuario hardcodeado con rol
        const user: User = {
            id: '1',
            name: 'Rosina Flores',
            role: 'admin' // Hardcodeado para pruebas
        };
        req.user = user;
        return next(); // Importante: llamar a next() para pasar al siguiente middleware
    }
    res.sendStatus(401); // No autorizado si la clave no es correcta
}

// Middleware para validar el rol
export function roles(allowedRoles: string[]) {
    return (req: Request, res: Response, next: NextFunction) => {
        if (req.user && allowedRoles.includes(req.user.role)) {
            return next(); // Continúa si el rol es permitido
        }
        return res.sendStatus(403); // Prohibido si el rol no es permitido
    };
}
