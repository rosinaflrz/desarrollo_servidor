//interface cumple siempre con todo los casos
export interface User {
    id?: string;
    name: string;
    email?: string;
    password?: string;
    role: string;
}