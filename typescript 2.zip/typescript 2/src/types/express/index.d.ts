import { User } from '../user'; // Asegúrate que la ruta a 'user' sea correcta

declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}
